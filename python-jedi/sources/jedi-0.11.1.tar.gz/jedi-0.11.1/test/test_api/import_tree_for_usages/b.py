def bar():
    pass
