# -*- coding: utf-8 -*-

import sys

sys.stdout.write('Test freeze module #2\n')
