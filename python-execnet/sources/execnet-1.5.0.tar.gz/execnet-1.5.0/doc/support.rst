Contact and Support channels
------------------------------

If you have interest, questions, issues or suggestions you
are welcome to:

* join `execnet-dev`_ for general discussions
* join `execnet-commit`_ to be notified of changes
* clone the `bitbucket repository`_ and submit patches
* hang out on the irc.freenode.net #pylib channel
* follow the `tetamap blog`_ or `Holger's twitter presence`_.
* contact merlinux_ if you want to buy teaching or other support.

.. _`Holger's twitter presence`: http://twitter.com/hpk42
.. _merlinux: http://merlinux.eu
.. _`tetamap blog`: http://holgerkrekel.net
.. _`execnet-dev`: http://mail.python.org/mailman/listinfo/execnet-dev
.. _`execnet-commit`: http://mail.python.org/mailman/listinfo/execnet-commit
.. _`bitbucket repository`: http://bitbucket.org/hpk42/execnet
