<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it_it">
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Salva tutti</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Sì</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Sì &amp;a tutti</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;o a tutti</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Interrompi</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Riprova</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignora</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Tralascia</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Ripristina</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Ripristina valori predefiniti</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>&amp;Undo</source>
        <translation>Ann&amp;ulla</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Rifai</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Taglia</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Incolla</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>&amp;Undo</source>
        <translation>Ann&amp;ulla</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Rifai</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Taglia</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Copia il co&amp;llegamento</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Incolla</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Seleziona tutto</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>&amp;Aumenta</translation>
    </message>
    <message>
        <source>Step &amp;down</source>
        <translation>&amp;Diminuisci</translation>
    </message>
</context>
</TS>
