<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_pl">
<context>
    <name>QPlatformTheme</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Zachowaj</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Zachowaj wszystko</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Tak</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>Ta&amp;k dla wszystkich</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;Nie</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>Ni&amp;e dla wszystkich</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Przerwij</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Ponów</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Zignoruj</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Odrzuć</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Zastosuj</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Zresetuj</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Przywróć domyślne</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>&amp;Select All</source>
        <translation>&amp;Zaznacz wszystko</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>Krok do &amp;góry</translation>
    </message>
    <message>
        <source>Step &amp;down</source>
        <translation>Krok w &amp;dół</translation>
    </message>
</context>
<context>
    <name>QWidgetTextControl</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Cofnij</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Przywróć</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>W&amp;ytnij</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>S&amp;kopiuj</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Skopiuj &amp;adres odsyłacza</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Wklej</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Zaznacz wszystko</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Cofnij</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Przywróć</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>W&amp;ytnij</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>S&amp;kopiuj</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Wklej</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Zaznacz wszystko</translation>
    </message>
</context>
</TS>
