Messages and Catalogs
=====================

Babel provides functionality to work with message catalogs.  This part of
the API documentation shows those parts.

.. toctree::
   :maxdepth: 2

   catalog
   extract
   mofile
   pofile
