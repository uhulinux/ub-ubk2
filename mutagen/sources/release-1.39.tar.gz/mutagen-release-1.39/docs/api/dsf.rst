DSF
---

.. automodule:: mutagen.dsf

.. autoclass:: mutagen.dsf.DSF(filething)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.dsf.DSFInfo()
    :members:
