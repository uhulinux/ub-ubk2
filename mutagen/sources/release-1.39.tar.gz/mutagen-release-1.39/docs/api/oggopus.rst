Ogg Opus
========

.. automodule:: mutagen.oggopus

.. autoclass:: mutagen.oggopus.OggOpus
    :show-inheritance:
    :members:

.. autoclass:: mutagen.oggopus.OggOpusInfo
    :show-inheritance:
    :members:
