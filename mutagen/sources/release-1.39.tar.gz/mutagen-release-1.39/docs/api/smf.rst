Standard MIDI File
==================

.. automodule:: mutagen.smf

.. autoclass:: mutagen.smf.SMF
    :show-inheritance:
    :members:

.. autoclass:: mutagen.smf.SMFInfo
    :members:
