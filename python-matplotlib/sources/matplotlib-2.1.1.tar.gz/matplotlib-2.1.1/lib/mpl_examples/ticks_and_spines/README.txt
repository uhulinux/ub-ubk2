.. _ticks_and_spines_examples:

Ticks and spines
================
