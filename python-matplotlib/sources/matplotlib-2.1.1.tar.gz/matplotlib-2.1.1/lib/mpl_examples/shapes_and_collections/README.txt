.. _shapes_and_collections_examples:


Shapes and collections
======================
