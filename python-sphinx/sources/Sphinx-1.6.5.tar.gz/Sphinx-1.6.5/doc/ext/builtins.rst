Builtin Sphinx extensions
-------------------------

These extensions are built in and can be activated by respective entries in the
:confval:`extensions` configuration value:

.. toctree::

   autodoc
   autosectionlabel
   autosummary
   coverage
   doctest
   extlinks
   githubpages
   graphviz
   ifconfig
   imgconverter
   inheritance
   intersphinx
   linkcode
   math
   napoleon
   todo
   viewcode
