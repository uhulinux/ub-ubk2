:tocdepth: 2

.. default-role:: any

.. _changes:

Changes in Sphinx
*****************

.. include:: ../CHANGES
