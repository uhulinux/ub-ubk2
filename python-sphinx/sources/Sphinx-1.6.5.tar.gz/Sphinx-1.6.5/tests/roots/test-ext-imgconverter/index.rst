test-ext-imgconverter
=====================

.. image:: svgimg.svg
