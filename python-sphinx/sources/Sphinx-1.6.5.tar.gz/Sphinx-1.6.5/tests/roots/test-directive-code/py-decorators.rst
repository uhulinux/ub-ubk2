py-decorators
=============

Various decorators
------------------

.. literalinclude:: py-decorators.inc
   :name: literal_include_pydecorators_1
   :pyobject: TheClass

.. literalinclude:: py-decorators.inc
   :name: literal_include_pydecorators_2
   :pyobject: TheClass.the_method

.. literalinclude:: py-decorators.inc
   :name: literal_include_pydecorators_3
   :pyobject: the_function
