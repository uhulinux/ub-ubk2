from os import *


class Foo:
    def __init__(self):
        pass

    def bar(self):
        pass
