
.. autosummary::
   :toctree: generated

   autosummary_dummy_module
   autosummary_dummy_module.Foo
