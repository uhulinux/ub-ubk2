import sys, os

sys.path.insert(0, os.path.abspath('.'))

extensions = ['sphinx.ext.autosummary']
autosummary_generate = True

# The suffix of source filenames.
source_suffix = '.rst'
