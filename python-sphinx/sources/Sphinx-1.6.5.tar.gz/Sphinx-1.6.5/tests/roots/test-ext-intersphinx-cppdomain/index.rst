test-ext-intersphinx-cppdomain
==============================

.. cpp:namespace:: foo

:cpp:class:`Bar`

.. cpp:function:: std::uint8_t FooBarBaz()
