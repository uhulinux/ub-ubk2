extensions = ['sphinx.ext.doctest']

project = 'test project for doctest'
master_doc = 'doctest'
source_suffix = '.txt'
exclude_patterns = ['_build']
