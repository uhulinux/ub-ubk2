# example.sphinx


class DummyClass(object):
    pass
